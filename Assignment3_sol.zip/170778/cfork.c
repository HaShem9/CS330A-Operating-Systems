// Vaibhav Thakkar
// 170778

#include <cfork.h>
#include <page.h>
#include <mmap.h>



/* You need to implement cfork_copy_mm which will be called from do_cfork in entry.c. Don't remove copy_os_pts()*/
void cfork_copy_mm(struct exec_context *child, struct exec_context *parent ){
    void *os_addr;
    u64 vaddr; 
    struct mm_segment *seg;

    child->pgd = os_pfn_alloc(OS_PT_REG);

    os_addr = osmap(child->pgd);
    bzero((char *)os_addr, PAGE_SIZE);

    //CODE segment
    seg = &parent->mms[MM_SEG_CODE];
    for(vaddr = seg->start; vaddr < seg->next_free; vaddr += PAGE_SIZE){
        u64 *parent_pte =  get_user_pte(parent, vaddr, 0);
        if(parent_pte){
            // Although CODE segment is read only but still making sure
            *parent_pte = *parent_pte >> 2;
            *parent_pte = *parent_pte << 2;
            *parent_pte = *parent_pte | 0x1;
            
            u32 pfn = ((*parent_pte & FLAG_MASK) >> PAGE_SHIFT);

            // Now creating the physical mapping in child
            map_physical_page((u64) os_addr, vaddr, 0, pfn);
            
            // now increase the refcount for that physical page
            increment_pfn_info_refcount(get_pfn_info(pfn)); 

            //install_ptable((u64) os_addr, seg, vaddr, (*parent_pte & FLAG_MASK) >> PAGE_SHIFT);   -- this won't work as we want to give only read access
        }
    } 

    //RODATA segment
    seg = &parent->mms[MM_SEG_RODATA];
    for(vaddr = seg->start; vaddr < seg->next_free; vaddr += PAGE_SIZE){
        u64 *parent_pte =  get_user_pte(parent, vaddr, 0);
        if(parent_pte)
            // Although RODATA segment is read only but still making sure
            *parent_pte = *parent_pte >> 2;
            *parent_pte = *parent_pte << 2;
            *parent_pte = *parent_pte | 0x1;

            u32 pfn = ((*parent_pte & FLAG_MASK) >> PAGE_SHIFT);

            // Now creating the physical mapping in child
            map_physical_page((u64) os_addr, vaddr,0,(*parent_pte & FLAG_MASK) >> PAGE_SHIFT); 

            // now increase the refcount for that physical page
            increment_pfn_info_refcount(get_pfn_info(pfn)); 

            //install_ptable((u64) os_addr, seg, vaddr, (*parent_pte & FLAG_MASK) >> PAGE_SHIFT);   -- this won't work as we want to give only read access
    } 

    //DATA segment
    seg = &parent->mms[MM_SEG_DATA];
    for(vaddr = seg->start; vaddr < seg->next_free; vaddr += PAGE_SIZE){
        u64 *parent_pte =  get_user_pte(parent, vaddr, 0);
        
        if(parent_pte){
            // Making pfn read only
            *parent_pte = *parent_pte >> 2;
            *parent_pte = *parent_pte << 2;
            *parent_pte = *parent_pte | 0x1;

            u32 pfn = ((*parent_pte & FLAG_MASK) >> PAGE_SHIFT);

            // Now creating the physical mapping in child
            map_physical_page((u64) os_addr, vaddr,0,(*parent_pte & FLAG_MASK) >> PAGE_SHIFT); 

            // now increase the refcount for that physical page
            increment_pfn_info_refcount(get_pfn_info(pfn)); 

            //install_ptable((u64) os_addr, seg, vaddr, (*parent_pte & FLAG_MASK) >> PAGE_SHIFT);   -- this won't work as we want to give only read access
            // u64 pfn = install_ptable((u64)os_addr, seg, vaddr, 0);  //Returns the blank page  
            // pfn = (u64)osmap(pfn);
            // memcpy((char *)pfn, (char *)(*parent_pte & FLAG_MASK), PAGE_SIZE); 
        }
    } 

    //STACK segment -- this will be new for child also
    seg = &parent->mms[MM_SEG_STACK];
    for(vaddr = seg->end - PAGE_SIZE; vaddr >= seg->next_free; vaddr -= PAGE_SIZE){
        u64 *parent_pte =  get_user_pte(parent, vaddr, 0);
        
        if(parent_pte){
            u64 pfn = install_ptable((u64)os_addr, seg, vaddr, 0);  //Returns the blank page  
            pfn = (u64)osmap(pfn);
            memcpy((char *)pfn, (char *)(*parent_pte & FLAG_MASK), PAGE_SIZE); 
        }
    } 

    // Now MMAP Segment
    // For this we also we have to create new vm_area because they are a linked list
    // and currently child's vm_area are pointing to parent's vm_areas -- BAD
    child->vm_area = NULL;
    struct vm_area* head = parent->vm_area;
    struct vm_area* child_head = NULL;
    struct vm_area* prev_child_vm_area = NULL;

    while(head!=NULL){
        struct vm_area* curr=alloc_vm_area();
        curr->vm_start = head->vm_start;
        curr->vm_end   = head->vm_end;
        curr->access_flags = head->access_flags;
        curr->vm_next = NULL;

        if(prev_child_vm_area == NULL){
            child->vm_area = curr;
        }
        else{
            prev_child_vm_area->vm_next = curr;
        }

        // Now changing physical mapping for pages of this vm_area to read only for both parent and child
        for(vaddr = curr->vm_start; vaddr < curr->vm_end; vaddr += PAGE_SIZE)
        {
            u64* parent_pte =  get_user_pte(parent, vaddr, 0);
            
            if(parent_pte){
                // Making pfn read only
                *parent_pte = *parent_pte >> 2;
                *parent_pte = *parent_pte << 2;
                *parent_pte = *parent_pte | 0x1;

                u32 pfn = ((*parent_pte & FLAG_MASK) >> PAGE_SHIFT);

                // Now creating the physical mapping in child
                map_physical_page((u64) os_addr, vaddr, 0,(*parent_pte & FLAG_MASK) >> PAGE_SHIFT); 

                // now increase the refcount for that physical page
                increment_pfn_info_refcount(get_pfn_info(pfn)); 

                //install_ptable((u64) os_addr, seg, vaddr, (*parent_pte & FLAG_MASK) >> PAGE_SHIFT);   -- this won't work as we want to give only read access
            }

            asm volatile ("invlpg (%0);" 
                    :: "r"(vaddr) 
                    : "memory");   // Flush TLB
        }


        prev_child_vm_area = curr;
        head = head->vm_next;
    }

    copy_os_pts(parent->pgd, child->pgd); 
    return; 
    
}

/* You need to implement vfork_copy_mm which will be called from do_vfork in entry.c.*/
void vfork_copy_mm(struct exec_context *child, struct exec_context *parent ){
    // parent shoud wait
    parent->state = WAITING;

    // We have to ensure child does not modify parent's stack
    struct mm_segment* stack_seg = &parent->mms[MM_SEG_STACK];

    // child should share physical mappings and vm_areas of parent
    child->pgd     = parent->pgd;
    child->vm_area = parent->vm_area;

    // copy stack data on top of parent's stack
    // We will copy each page of parent's stack
    u64 stack_size = stack_seg->end - stack_seg->next_free;
    for(u64 vaddr = stack_seg->end - PAGE_SIZE; vaddr >= stack_seg->next_free; vaddr -= PAGE_SIZE){
        u64* parent_pte =  get_user_pte(parent, vaddr, 0);
        void* os_addr = osmap(child->pgd);
        
        if(parent_pte){
            // copy parent's data to child's stack which is on top of parent stack
            u64 pfn = install_ptable((u64)os_addr, stack_seg, vaddr-(stack_size), 0); 
            pfn = (u64)osmap(pfn);

            // copy the entire PFN to child
            memcpy((char *)pfn, (char *)(*parent_pte & FLAG_MASK), PAGE_SIZE); 
        }

        asm volatile ("invlpg (%0);" 
                    :: "r"(vaddr)
                    : "memory");   // Flush TLB
    }

    // Now all physical pages have been copied by child also
    // now we have to shift the stack pointer and base pinter of child
    child->regs.rbp       = parent->regs.rbp - (stack_size);        // setting rbp
    child->regs.entry_rsp = parent->regs.entry_rsp - (stack_size);  // setting rsp

    // Now change child's stack segment end
    stack_seg = &child->mms[MM_SEG_STACK];
    stack_seg->end = stack_seg->end - (stack_size);

    // now change next-free of stack
    stack_seg->next_free = stack_seg->next_free - (stack_size);

    return;
}

/*You need to implement handle_cow_fault which will be called from do_page_fault 
incase of a copy-on-write fault

* For valid acess. Map the physical page 
 * Return 1
 * 
 * For invalid access,
 * Return -1. 
*/

int handle_cow_fault(struct exec_context *current, u64 cr2){
    // remember to check testcase 3 of task 2
    if( ((char*)cr2) == NULL) return -1;

    // checking if CODE or RD_ONLY data, on which write cannot happen
    // Also there sizes are fixed at compile time
    if((cr2 >= CODE_START) && (cr2<DATA_START)) return -1;

    // Check if pte entry exist although error code 0x7 can only occur on already existing pte, but still verifying
    u64* entry = get_user_pte(current, cr2, 0);
    if(!entry) return -1;

    // Now to check MMAP and DATA part as stack is already separate for both parent and child and writable
    // Check in MMAP region by checking access
    if((cr2>=MMAP_AREA_START) && (cr2<MMAP_AREA_END)){
        struct vm_area* head = current->vm_area;

        while(head!=NULL){
            if((cr2 >= head->vm_start) && (cr2 < head->vm_end)){
                // Page lies in this vm area
                if((head->access_flags & PROT_WRITE) != PROT_WRITE)
                    return -1;  // write not allowed

                break;
            }
            head  = head->vm_next;
        }

        // No vm_area found
        if(head == NULL) return -1;
    }

    // Now this means we have to copy on write
    struct pfn_info *ptr = get_pfn_info( (*entry >> PTE_SHIFT) );
    if(ptr->refcount > 1){
        u64 pfn = map_physical_page((u64)osmap(current->pgd), cr2, MM_RD | MM_WR, 0);
        memcpy((char *)pfn, (char *)((*entry) & FLAG_MASK), PAGE_SIZE);
        decrement_pfn_info_refcount(ptr);
    }
    else{
        *entry = *entry | MM_WR;
    }


    asm volatile ("invlpg (%0);" 
                    :: "r"(cr2) 
                    : "memory");   // Flush TLB

    return 1;
}

/* You need to handle any specific exit case for vfork here, called from do_exit*/
void vfork_exit_handle(struct exec_context *ctx){
    
    struct exec_context* parent_ctx = get_ctx_by_pid(ctx->ppid);

    // Check if process exiting is child
    if(parent_ctx->pgd == ctx->pgd){
        // parent is now ready to be scheduled
        parent_ctx->state = READY;

        // In case child has completely emptied parent's vm_areas
        if(ctx->vm_area==NULL) 
            parent_ctx->vm_area=NULL;

        // now remove all physical mappings of stack created for child
        struct mm_segment* stack_seg = &ctx->mms[MM_SEG_STACK];
        for(u64 vaddr = stack_seg->end - PAGE_SIZE; vaddr >= stack_seg->next_free; vaddr -= PAGE_SIZE){
            // Unmap physical mapping
            u64* pte_entry = get_user_pte(ctx, vaddr, 0);
            if(pte_entry){
                os_pfn_free(USER_REG, (*pte_entry >> PTE_SHIFT) & 0xFFFFFFFF);
                *pte_entry = 0;

                asm volatile ("invlpg (%0);" 
                    :: "r"(vaddr) 
                    : "memory");   // Flush TLB
            }
        }
    }

    return;
}