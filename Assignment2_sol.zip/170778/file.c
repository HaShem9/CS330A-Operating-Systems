/*

Name: Vaibhav Thakkar
Roll no. : 170778

*/
#include<types.h>
#include<context.h>
#include<file.h>
#include<lib.h>
#include<serial.h>
#include<entry.h>
#include<memory.h>
#include<fs.h>
#include<kbd.h>
#include<pipe.h>


/************************************************************************************/
/***************************Do Not Modify below Functions****************************/
/************************************************************************************/
void free_file_object(struct file *filep)
{
    if(filep)
    {
       os_page_free(OS_DS_REG ,filep);
       stats->file_objects--;
    }
}

struct file *alloc_file()
{
  
  struct file *file = (struct file *) os_page_alloc(OS_DS_REG); 
  file->fops = (struct fileops *) (file + sizeof(struct file)); 
  bzero((char *)file->fops, sizeof(struct fileops));
  stats->file_objects++;
  return file; 
}

static int do_read_kbd(struct file* filep, char * buff, u32 count)
{
  kbd_read(buff);
  return 1;
}

static int do_write_console(struct file* filep, char * buff, u32 count)
{
  struct exec_context *current = get_current_ctx();
  return do_write(current, (u64)buff, (u64)count);
}

struct file *create_standard_IO(int type)
{
  struct file *filep = alloc_file();
  filep->type = type;
  if(type == STDIN)
     filep->mode = O_READ;
  else
      filep->mode = O_WRITE;
  if(type == STDIN){
        filep->fops->read = do_read_kbd;
  }else{
        filep->fops->write = do_write_console;
  }
  filep->fops->close = generic_close;
  filep->ref_count = 1;
  return filep;
}

int open_standard_IO(struct exec_context *ctx, int type)
{
   int fd = type;
   struct file *filep = ctx->files[type];
   if(!filep){
        filep = create_standard_IO(type);
   }else{
         filep->ref_count++;
         fd = 3;
         while(ctx->files[fd])
             fd++; 
   }
   ctx->files[fd] = filep;
   return fd;
}
/**********************************************************************************/
/**********************************************************************************/
/**********************************************************************************/
/**********************************************************************************/



void do_file_fork(struct exec_context *child)
{
   /*TODO the child fds are a copy of the parent. Adjust the refcount*/
   for(int i=0;i<MAX_OPEN_FILES;i++){
     if(child->files[i]!=NULL)
       child->files[i]->ref_count ++ ;
   }
 
}

void do_file_exit(struct exec_context *ctx)
{
   /*TODO the process is exiting. Adjust the ref_count
     of files*/
   for(int i=0;i<MAX_OPEN_FILES;i++){
     if(ctx->files[i]!=NULL)
       ctx->files[i]->fops->close(ctx->files[i]);
   }
     
}

long generic_close(struct file *filep)
{
  /** TODO Implementation of close (pipe, file) based on the type 
   * Adjust the ref_count, free file object
   * Incase of Error return valid Error code 
   * 
   */
    if(!filep)
      return -EINVAL;
    filep->ref_count--;

    if(filep->type == PIPE){ // PIPE

      if(filep->ref_count == 0){
        if(filep->mode & O_READ)
          filep->pipe->is_ropen = 0;
        else
          filep->pipe->is_wopen = 0;

        if(filep->pipe->is_ropen == 0 && filep->pipe->is_wopen == 0) 
          free_pipe_info(filep->pipe); // as now both ends of pipe are closed
        free_file_object(filep); 
      }
    }
    else{     // Regular File or STDIN or STDOUT or STDERR
      if(filep->ref_count == 0)
        free_file_object(filep);  
    }

    return 0;
}

static int do_read_regular(struct file *filep, char * buff, u32 count)
{
   /** TODO Implementation of File Read, 
    *  You should be reading the content from File using file system read function call and fill the buf
    *  Validate the permission, file existence, Max length etc
    *  Incase of Error return valid Error code 
    * */

    if(!filep)  // filep is NULL
      return -EINVAL;
    
    if(!(filep->mode & O_READ))   // Reading not allowed
      return -EACCES;

    long int max_len;
    max_len = (long int)filep->inode->max_pos - (long int)filep->offp - (long int)filep->inode->s_pos;
    if(max_len < count) // Cannot read more than file size
      return -EINVAL;

    int rd_count = flat_read(filep->inode, buff, count, &filep->offp);
    filep->offp += rd_count;
    return rd_count;
}


static int do_write_regular(struct file *filep, char * buff, u32 count)
{
    /** TODO Implementation of File write, 
    *   You should be writing the content from buff to File by using File system write function
    *   Validate the permission, file existence, Max length etc
    *   Incase of Error return valid Error code 
    * */

    if(!filep)  // filep is NULL
      return -EINVAL;
    
    if(!(filep->mode & O_WRITE))   // Writing not allowed
      return -EACCES;

    int write_count = flat_write(filep->inode, buff, count, &filep->offp);
    if(write_count == -1)   // file_size exceeded
      return -EOTHERS;
  
    filep->offp += write_count;
    return write_count;
}

static long do_lseek_regular(struct file *filep, long offset, int whence)
{
    /** TODO Implementation of lseek 
    *   Set, Adjust the ofset based on the whence
    *   Incase of Error return valid Error code 
    * */
    if(!filep) // filep is NULL
      return -EINVAL;

    long modified_offset = filep->offp;
    if(whence == SEEK_SET)      modified_offset  = offset;
    else if(whence == SEEK_CUR) modified_offset += offset;
    else if(whence == SEEK_END) modified_offset  = filep->inode->file_size + offset;
    else return -EINVAL;

    if((modified_offset < 0) || (modified_offset > (filep->inode->e_pos - filep->inode->s_pos)))
      return -EINVAL;

    filep->offp = modified_offset;
    return modified_offset;
}

extern int do_regular_file_open(struct exec_context *ctx, char* filename, u64 flags, u64 mode)
{ 
  /**  TODO Implementation of file open, 
    *  You should be creating file(use the alloc_file function to creat file), 
    *  To create or Get inode use File system function calls, 
    *  Handle mode and flags 
    *  Validate file existence, Max File count is 32, Max Size is 4KB, etc
    *  Incase of Error return valid Error code 
    * */
    if(!ctx)
      return -EINVAL;

    int ret_fd = -EINVAL; 
    struct inode* file_node = lookup_inode(filename);

    if(!file_node){   // File does not exist  
      if(!(flags & O_CREAT))
        return -EINVAL;

      file_node = create_inode(filename, mode);
      if(!file_node)  // If creating file returns error
        return -ENOMEM;
    }
    else{
      if(flags & O_CREAT)
        return -EINVAL;

      // Some Flag is not present in mode
      if((flags & file_node->mode) != flags)
        return -EACCES;
    }

    struct file *filep = alloc_file();
    if(filep == NULL)
      return -ENOMEM;

    filep->type  = REGULAR;
    filep->mode  = flags;
    filep->ref_count = 0;
    filep->inode = file_node;
    filep->pipe = NULL;
    filep->offp = 0;

    // Finding empty file descriptor
    for(int i=3; i<MAX_OPEN_FILES; i++){
      if(ctx->files[i] == NULL){
        ret_fd = i;
        ctx->files[i] = filep;
        break;
      }
    }
    
    filep->ref_count   = 1;
    filep->fops->read  = do_read_regular;
    filep->fops->write = do_write_regular;
    filep->fops->lseek = do_lseek_regular;
    filep->fops->close = generic_close;

    return ret_fd;
}

int fd_dup(struct exec_context *current, int oldfd)
{
     /** TODO Implementation of dup 
      *  Read the man page of dup and implement accordingly 
      *  return the file descriptor,
      *  Incase of Error return valid Error code 
      * */
    if(oldfd<0 || oldfd>31)
      return -EINVAL; 
    
    if(current->files[oldfd] == NULL)
      return -EINVAL;

    int ret_fd = -EINVAL; 

    // Finding empty file descriptor
    for(int i=0; i<MAX_OPEN_FILES; i++){
      if(current->files[i] == NULL){
        ret_fd = i;
        current->files[i] = current->files[oldfd];
        break;
      }
    }
    
    current->files[oldfd]->ref_count ++;
    return ret_fd;
}


int fd_dup2(struct exec_context *current, int oldfd, int newfd)
{
  /** TODO Implementation of the dup2 
    *  Read the man page of dup2 and implement accordingly 
    *  return the file descriptor,
    *  Incase of Error return valid Error code 
    * */
    if(oldfd<0 || oldfd>31)
      return -EINVAL;
    
    if(newfd<0 || newfd>31)
      return -EINVAL;

    if(current->files[oldfd] == NULL)
      return -EINVAL;

    if(oldfd == newfd)
      return newfd;

    if(current->files[newfd] != NULL){
      long e = current->files[newfd]->fops->close(current->files[newfd]);
      if(e!=0)   // error in closing
        return e;
    }

    current->files[oldfd]->ref_count ++;
    current->files[newfd] = current->files[oldfd];
    return newfd;
}
